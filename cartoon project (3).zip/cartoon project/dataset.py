
# Cell 5: Load datasets
celeb_path = '/content/drive/MyDrive/Colab Notebooks/dupe'
cartoon_path = '/content/drive/MyDrive/Colab Notebooks/cartoonset10k'

# Load and preprocess images
try:
    dataA = normalize_images(load_images(celeb_path))
    dataB = normalize_images(load_images(cartoon_path))
    print(f"Dataset A shape: {dataA.shape}, Dataset B shape: {dataB.shape}")
except FileNotFoundError as e:
    print(f"Error loading datasets: {e}")
