# Dependencies
1.  Install tensorflow-addons

2.  Install tensorflow==2.13.0

3.  Install dependencies:

    ```
    python -m pip install tqdm pillow numpy matplotlib 
    ```
