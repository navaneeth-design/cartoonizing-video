from google.colab import files
from PIL import Image
import io

def upload_and_cartoonize():
    """Allow user to upload an image and apply the transformation."""
    uploaded = files.upload()  # Trigger file upload dialog
    for filename in uploaded.keys():
        # Load the image from the uploaded file
        content = uploaded[filename]
        img = Image.open(io.BytesIO(content)).resize((256, 256))
        img_array = np.array(img)
        img_normalized = normalize_images(np.expand_dims(img_array, axis=0))

        # Perform transformation
        transformed_image = g_model_AtoB.predict(img_normalized)[0]
        cartoonized_image = denormalize_images(transformed_image)

        # Display results
        plt.figure(figsize=(8, 4))
        plt.subplot(1, 2, 1)
        plt.title("Original Image")
        plt.imshow(img)
        plt.axis('off')

        plt.subplot(1, 2, 2)
        plt.title("Cartoonized Image")
        plt.imshow(cartoonized_image.astype(np.uint8))
        plt.axis('off')
        plt.show()
        
        
        try:
             upload_and_cartoonize()
        except Exception as e:
            print(f"Error during cartoonization: {e}")
