image_shape = (256, 256, 3)
g_model_AtoB = build_generator(image_shape)
g_model_BtoA = build_generator(image_shape)
d_model_A = build_discriminator(image_shape)
d_model_B = build_discriminator(image_shape)



optimizer = tf.keras.optimizers.Adam(learning_rate=0.0002, beta_1=0.5)


# Compile discriminators
d_model_A.compile(loss='mse', optimizer=optimizer, metrics=['accuracy'])
d_model_B.compile(loss='mse', optimizer=optimizer, metrics=['accuracy'])