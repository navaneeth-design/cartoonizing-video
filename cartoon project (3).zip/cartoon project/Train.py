# Cell 3: Define helper functions
def load_images(path, size=(256, 256)):
    """Load and preprocess images from a given path."""
    images = []
    for filename in os.listdir(path):
        if filename.endswith('.jpg') or filename.endswith('.png'):
            img = tf.keras.preprocessing.image.load_img(os.path.join(path, filename), target_size=size)
            img = tf.keras.preprocessing.image.img_to_array(img)
            images.append(img)
    return np.array(images)

def normalize_images(images):
    """Normalize images to [-1, 1]."""
    return (images / 127.5) - 1.0

def denormalize_images(images):
    """Denormalize images to [0, 255]."""
    return ((images + 1.0) * 127.5).astype(np.uint8)

def show_preds(original, transformed, reconstructed):
    """Visualize original, transformed, and reconstructed images."""
    plt.figure(figsize=(12, 4))
    for i, img in enumerate([original, transformed, reconstructed]):
        plt.subplot(1, 3, i + 1)
        plt.imshow((img + 1) / 2)
        plt.axis('off')
    plt.show()

# Cell 4: Define CycleGAN models
def build_generator(image_shape):
    """Build a generator model."""
    inputs = layers.Input(shape=image_shape)
    x = layers.Conv2D(64, (7, 7), padding='same', kernel_initializer='he_normal')(inputs)
    x = tfa.layers.InstanceNormalization()(x)
    x = layers.ReLU()(x)

    for _ in range(2):
        x = layers.Conv2D(128, (3, 3), strides=2, padding='same', kernel_initializer='he_normal')(x)
        x = tfa.layers.InstanceNormalization()(x)
        x = layers.ReLU()(x)

    for _ in range(9):
        x = residual_block(x)

    for _ in range(2):
        x = layers.Conv2DTranspose(64, (3, 3), strides=2, padding='same', kernel_initializer='he_normal')(x)
        x = tfa.layers.InstanceNormalization()(x)
        x = layers.ReLU()(x)

    outputs = layers.Conv2D(3, (7, 7), padding='same', activation='tanh', kernel_initializer='he_normal')(x)
    return Model(inputs, outputs)

def build_discriminator(image_shape):
    """Build a discriminator model."""
    inputs = layers.Input(shape=image_shape)
    x = layers.Conv2D(64, (4, 4), strides=2, padding='same', kernel_initializer='he_normal')(inputs)
    x = layers.LeakyReLU(0.2)(x)

    for filters in [128, 256, 512]:
        x = layers.Conv2D(filters, (4, 4), strides=2, padding='same', kernel_initializer='he_normal')(x)
        x = tfa.layers.InstanceNormalization()(x)
        x = layers.LeakyReLU(0.2)(x)

    x = layers.Conv2D(1, (4, 4), padding='same', kernel_initializer='he_normal')(x)
    return Model(inputs, x)

def residual_block(x):
    """Define a residual block."""
    inputs = x
    x = layers.Conv2D(128, (3, 3), padding='same', kernel_initializer='he_normal')(x)
    x = tfa.layers.InstanceNormalization()(x)
    x = layers.ReLU()(x)
    x = layers.Conv2D(128, (3, 3), padding='same', kernel_initializer='he_normal')(x)
    x = tfa.layers.InstanceNormalization()(x)
    return layers.Add()([inputs, x])
